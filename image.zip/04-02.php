<?php
    $num1 = $_GET["firstnum"];
    $num2 = $_GET["secondnum"];

    $num3 = $num1*$num2;

    echo("두 수의 곱은 {$num3} 입니다.");
    ?>